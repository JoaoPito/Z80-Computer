<-------------------- You viewer should be at least this wide ------------------>
Name:    Devpac8x
Author:  Scott "Wrath" Dial (TCPA)
Version: 1.0
Date:    5/9/00
Requires: DOS or >

Description:
   Devpac8x is the update to Devpac83 which turned bin files to 83p. Devpac8x
turns bin files into 8xp which can now be loaded into the flash simulator corre

Instructions:
asm.bat replaces the older asm.bat that comes with ion
zasm8x.bat is for compiling a z80 file to 8xp only

Both batch files use the following arguments in this order:
asm.bat FILENAME(w/o ext) [PATH]

These 8xp's should load into the flash simulator correctly now. Have fun...

Known Bugs:
   None

If you find any other bug, please, do not hesitate to email me at wrath@calc.org

What's New:

Credits:
   Coded by Hannes Edfelt aka movax (1998) movax@algonet.se

If you find any problems, have any suggestions, or just want to:
e-mail me at wrath@calc.org

(C) Copyright 2000 Scott Dial


