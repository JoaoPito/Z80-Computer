Here is the new TI83 Plus include file and a couple of BASIC programs that I
made (I won't tell you what the programs are about, I'll just let you find
out, hope you enjoy them!). Include file last updated on 6/20/02 and edited
by me, Brett, for use with the TASM assembler. I hope you enjoy these files
and keep on programming!!!!

Thank you Texas Instruments for making the include file!